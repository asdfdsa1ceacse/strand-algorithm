# Abstract DNA

**Structural matching that bypasses the semantic gap.**
99.9% coverage on 799 real queries. Zero LLM. Zero hallucination.

## Install

```bash
pip install abstract-dna
```

Or from source:
```bash
git clone https://github.com/asdfdsa1ceacse/strand-algorithm.git
cd strand-algorithm/abstract-dna
pip install .
```

## Quick Start

```python
from abstract_dna import pipeline

# Single query
result = pipeline("帮我装个nginx")
print(result['signals'])   # {'action:setup': 0.3}
print(result['entities'])  # []

# Rule table only (no DNA pool needed)
from abstract_dna import RuleChannel
ch = RuleChannel()
signals = ch.match("服务器重启一下")
print(signals)  # {'action:process': 0.3, 'entity:machine': 0.2}

# With normalization
from abstract_dna import normalize
print(normalize("帮我装一下这个数据库"))  # "安装 数据库"
```

## Papers

- [English Paper](https://github.com/asdfdsa1ceacse/strand-algorithm/blob/main/abstract-dna/PAPER.en.md)
- [中文论文](https://github.com/asdfdsa1ceacse/strand-algorithm/blob/main/abstract-dna/PAPER.zh.md)

## Results

| Metric | Value |
|--------|:-----:|
| 799 real queries coverage | **99.9%** |
| Rule table alone | **86.5%** |
| Adversarial queries (58) | **67%** |
| Avg latency | **~11ms** |
| External dependencies | **0** |

## License

MIT
